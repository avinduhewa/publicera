const makeResponse = require('./makeResponse');
const db = require('./mongodb');

module.exports.makeResponse = makeResponse;
module.exports.db = db;